package Project;

import java.net.URL;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.concurrent.ThreadLocalRandom;

import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.util.Duration;


public class GameController implements Initializable,EventHandler<KeyEvent>{
	@FXML
	public AnchorPane background;
	public ImageView ship;
	public ImageView bullet;
	public ImageView BrownMeteor;
	public ImageView greyMeteor;
	public ImageView star;
	public ImageView Energy;
	public ImageView playerLife1;
	public ImageView playerLife2;
	public ImageView playerLife3;
	public Label Points;
	public Label point;
	public Pane pointPane;
	public Pane playerLifePane;
	Image image2 ;
	ImageView [] greyMeteors;
	ImageView [] stars;
	

	Random RandomPositionGenerator = new Random();
	AnimationTimer gameTimer;
	Boolean gameOn;
	int Point = 0;
	int angle = 0;
	int playerLife = 3;
	String Name ;
	
	ImageView brownMeteor = new ImageView();
	ImageView energy = new ImageView();
	LinkedList<ImageView> bullets = new LinkedList<ImageView>();
	
	public void setName(String name) {
		Name = name;
	}
	
	public void setShipImage(int number) {
		if(number == 1) {
			Image image = new Image("/project/shipRed.png");
			ship.setImage(image);
			image2 = new Image("/project/shipRedLife.png");
		}
		else if(number == 2) {
			Image image = new Image("/project/shipOrange.png");
			ship.setImage(image);
			image2 = new Image("/project/shipOrangeLife.png");
		}
		else if(number == 3) {
			Image image = new Image("/project/shipGreen.png");
			ship.setImage(image);
			image2 = new Image("/project/shipGreenLife.png");
		}
		else if(number == 4) {
			Image image = new Image("/project/shipBlue.png");
			ship.setImage(image);
			image2 = new Image("/project/shipBlueLife.png");
		}
		playerLife1.setImage(image2);
		playerLife2.setImage(image2);
		playerLife3.setImage(image2);
	}
	
	
	
	public void createNewGame(Boolean value) {
		Points.setText(Name +" :");
		createElements();
		createGameloop();
	}
	// get the keyboard
	public void handle(KeyEvent e) {
		if(e.getCode() == KeyCode.LEFT) {
			if(ship.getLayoutX() <= 10) {
				ship.setLayoutX(0);
			}
			else {
				ship.setLayoutX(ship.getLayoutX()-10);
			}
		}
		if(e.getCode() == KeyCode.RIGHT) {
			if(ship.getLayoutX() >= 600-ship.getFitWidth()) {
				ship.setLayoutX(600-ship.getFitWidth());
			}
			else 
				ship.setLayoutX(ship.getLayoutX()+10);
			}
		
		if(e.getCode() == KeyCode.UP) {
			if(ship.getLayoutY()<=ship.getFitHeight()) {
				ship.setLayoutY(0);
			}
			else {
				ship.setLayoutY(ship.getLayoutY()-7);
			}
		}
		if(e.getCode() == KeyCode.DOWN) {
			if(ship.getLayoutY()>=700-ship.getFitHeight()) {
				ship.setLayoutY(700-ship.getFitHeight());
			}
			else {
				ship.setLayoutY(ship.getLayoutY()+7);
			}
		}
	
		
		if(e.getCode() == KeyCode.SPACE) {
			ImageView newBullet = new ImageView(bullet.getImage());
			newBullet.setLayoutX(ship.getLayoutX()+ ship.getFitWidth()/2);
			newBullet.setLayoutY(ship.getLayoutY());
			bullets.push(newBullet);
			background.getChildren().add(newBullet);
		}
	}
	
	// run the method 
	public void createGameloop() {

		moveBrownMeteor m1 = new moveBrownMeteor();
		Thread t1 = new Thread(m1);
		moveGreyMeteor m2 = new moveGreyMeteor();
		Thread t2 = new Thread(m2);
		moveStar m3 = new moveStar();
		Thread t3 = new Thread(m3);
		moveEngry m4 = new moveEngry();
		Thread t4 = new Thread(m4);
		
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		
	}
	//create the elements
	public void createElements() {
		
		brownMeteor.setImage(BrownMeteor.getImage());
		setNewPosition(brownMeteor);
		background.getChildren().add(brownMeteor);
	
		greyMeteors = new ImageView[2];
		for(int i=0;i<greyMeteors.length;i++) {
			greyMeteors[i] = new ImageView(greyMeteor.getImage());
			setNewPosition(greyMeteors[i]);
			background.getChildren().add(greyMeteors[i]);
		}	
		
		stars = new ImageView[2];
		for(int i=0;i<stars.length;i++) {
			stars[i] = new ImageView(star.getImage());
			setNewPosition(stars[i]);
			background.getChildren().add(stars[i]);
		}	
		
		energy.setImage(Energy.getImage());
		setNewPosition(energy);
		background.getChildren().add(energy);
	}
	
	class moveBrownMeteor implements Runnable{
		public void run() {
			while(true) {
				move(brownMeteor,4);
				checkCollision(brownMeteor, 0);
				try {
					Thread.sleep(sleepTime());
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	class moveGreyMeteor implements Runnable{
		public void run() {
			while(true) {
				move(greyMeteors[0],3);
				checkCollision(greyMeteors[0],0);
				move(greyMeteors[1],2);
				checkCollision(greyMeteors[1],0);
				try {
					Thread.sleep(sleepTime());
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	class moveStar implements Runnable{
		public void run() {
			while(true) {
				move(stars[0], 5);
				checkCollision(stars[0], 1);
				move(stars[1], 5);
				checkCollision(stars[1], 1);
				try {
					Thread.sleep(sleepTime());
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
				}
			}
		}
	}
	class moveEngry implements Runnable{
		public void run() {
			while(true) {
				move(energy, 7);
				checkCollision(energy,2);
				try {
					Thread.sleep(sleepTime());
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	// move elements
	public synchronized void move(ImageView image, int yCount) {
		Platform.runLater(()->{
			image.setLayoutY(image.getLayoutY()+yCount);
			image.setRotate(image.getRotate()+4);
			if(image.getLayoutY() > 700) {
				setNewPosition(image);
			}
		});
	}
	
	// set new elements
	public synchronized void setNewPosition(ImageView image) {
		Platform.runLater(()->{
			image.setLayoutX(RandomPositionGenerator.nextInt(560));
			image.setLayoutY(RandomPositionGenerator.nextInt(200));
		});
	}
	
	// set the point 
	public synchronized void checkCollision(ImageView image, int count) {
		Platform.runLater(()->{
			if((image.getLayoutX()>=ship.getLayoutX()) && (image.getLayoutX()<=ship.getLayoutX()+ship.getFitWidth()) 
					&& (image.getLayoutY()>=ship.getLayoutY()-ship.getFitHeight()+30) &&(image.getLayoutY()<=ship.getLayoutY())) {
				switch (count){
					case 0:													// brownMeteor && greyMeteor
						if(Point > 0)
							Point -= 10;
						setLife(0);
						break;
					case 1:													// star
						Point += 10;
						break;
					case 2:													// energy
						Point += 10;
						setLife(1);
						break;
				}
				setNewPosition(image);
				point.setText(String.valueOf(Point));
			}
		});
	}
	
	//remove player life image
	public synchronized void setLife(int addOrRemove) {
		if(addOrRemove == 0) {
			playerLife--;
			Platform.runLater(()->{
				if(playerLife == 2) 
					playerLife3.setImage(null);
				else if(playerLife == 1) 
					playerLife2.setImage(null);
				else if(playerLife == 0) 
					playerLife1.setImage(null);
				else if(playerLife < 0) 
					Main.currentStage.setScene(Main.menuScene);	
			});
		}
		else if(addOrRemove == 1){
			//System.out.println(playerLife);
			if(playerLife < 3) {
				Platform.runLater(()->{
					if(playerLife == 2) 
						playerLife3.setImage(image2);
					else if(playerLife == 1)
						playerLife2.setImage(image2);
					else if(playerLife == 0)
						playerLife1.setImage(image2);
					playerLife++;
				});
			}
		}
	}
	public int sleepTime(){
		int t = ThreadLocalRandom.current().nextInt(30,70);
		return t;
	}

	@Override
	public void initialize(URL url,ResourceBundle rb) {
		ImageView ship = new ImageView();
		ImageView playerLife1 = new ImageView();
		ImageView playerLife2 = new ImageView();
		ImageView playerLife3 = new ImageView();
		Label point = new Label("000");
		Pane playerLifePane = new Pane();
		background.getChildren().add(playerLifePane);
		Timeline fps = new Timeline(new KeyFrame(Duration.millis(1000/60),(e) ->{
			ArrayList<ImageView> Bullets = new ArrayList<ImageView>(bullets);
			for(var b : Bullets) {
		
					b.setLayoutY(b.getLayoutY()-5);
					if(b.getLayoutY() <= brownMeteor.getLayoutY() && b.getLayoutY() >= b.getLayoutY() + brownMeteor.getFitHeight()&& 
					   b.getLayoutX() >= brownMeteor.getLayoutX() && b.getLayoutX() <= brownMeteor.getLayoutX()+45) {
							setNewPosition(brownMeteor);
							bullets.remove(b);
							background.getChildren().remove(b);
						}
					for(int i=0;i<greyMeteors.length;i++){
						if(b.getLayoutY() <= greyMeteors[i].getLayoutY() && b.getLayoutY() >= b.getLayoutY() + greyMeteors[i].getFitHeight()&&
						   b.getLayoutX() >= greyMeteors[i].getLayoutX() && b.getLayoutX() <= greyMeteors[i].getLayoutX()+26) {
							setNewPosition(greyMeteors[i]);
							bullets.remove(b);
							background.getChildren().remove(b);
							}
						}
					if(b.getLayoutY()<0) {
						bullets.remove(b);
						background.getChildren().remove(b);
					}
			}}));
			fps.setCycleCount(Timeline.INDEFINITE);
			fps.play();
		}
	}


