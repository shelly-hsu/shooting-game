package Project;import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import java.io.IOException;
import java.net.URL;
import javafx.fxml.Initializable;
import java.util.ResourceBundle;

public class MenuController implements Initializable{

	@FXML
	public Button Play;
	public Button Help;
	public Button Scores;
	public Button Exit;
	public BorderPane mainPane;
	public Pane ScoresPane;
	public TextField textfield;

	public RadioButton Red_RadioButton;
	public RadioButton Orange_RadioButton;
	public RadioButton Green_RadioButton;
	public RadioButton Blue_RadioButton;
    
	public ImageView redship;
	public ImageView orangeship;
	public ImageView greenship;
	public ImageView blueship;
	
	String name = "";
	public int number=0;
	GameController gamecon = new GameController();
	@FXML
	public void PlayPressed() {
		FxmlLoader object = new FxmlLoader();
		Pane view = object.getPane("playScreen");
		mainPane.setRight(view);
	}
	@FXML
	public void HelpPressed() {

		FxmlLoader object = new FxmlLoader();
		Pane view = object.getPane("helpScreen");
		mainPane.setRight(view);
	}
	@FXML
	public void ScoresPressed() {
		FxmlLoader object = new FxmlLoader();
		Pane view = object.getPane("scoresScreen");
		mainPane.setRight(view);
	}
	@FXML
	public void ExitPressed() {
		Main.currentStage.close();
	}
	@FXML
	public void StartPressed()throws IOException{
		if(number != 0) {
			name = textfield.getText();
			FXMLLoader loader = new FXMLLoader(getClass().getResource("game.fxml"));
			Pane pane = (Pane) loader.load();
			Scene gameScene = new Scene(pane);
			gameScene.getRoot().requestFocus();
			Main.currentStage.setScene(gameScene);
			GameController con = loader.<GameController>getController();
			con.setShipImage(number);
			con.setName(name);
			con.createNewGame(true);
		}
	}
	
	
	public void RadioButtonPressed() {
		
		if(Red_RadioButton.isSelected()) {
			 number=1;
		 }
		 if(Orange_RadioButton.isSelected()) {
			 number=2;
		 }
		 if(Green_RadioButton.isSelected()) {
			 number=3;
		 }
		 if(Blue_RadioButton.isSelected()) {
		 	number=4;
		 }
	 }
	

	@Override
	public void initialize(URL url,ResourceBundle rb) {
	}
}


